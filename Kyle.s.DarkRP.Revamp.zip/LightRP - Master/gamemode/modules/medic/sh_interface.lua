DarkRP.PLAYER.isMedic = DarkRP.stub{
    name = "isMedic",
    description = "Whether this player is a medic.",
    parameters = {
    },
    returns = {
        {
            name = "answer",
            description = "Whether this player is a medic.",
            type = "boolean"
        }
    },
    metatable = DarkRP.PLAYER
}
