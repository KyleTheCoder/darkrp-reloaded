
[//]: # (Github is not the place to ask for help or just to ask questions.)
[//]: # (That's what the forums (http://forum.darkrp.com/) are for instead.)

### Description of the bug
[//]: # (Describe the issue as accurately as possible)


### How to make the bug happen
[//]: # (Knowing how to make a bug happen allows the developers to figure out)
[//]: # (what the cause of the problem is and whether a certain fix solves it)


### Lua errors
[//]: # (Note that errors on server startup are more important than other ones)
[//]: # (because they can cause other errors. Always look in the startup log of the server!)


### Why the developer of DarkRP is responsible for this issue
[//]: # (By posting on Github, you ask the developers of DarkRP to solve the problem)
[//]: # (It may seem obvious to you, but you have to make clear why they are the right people to look at it)
